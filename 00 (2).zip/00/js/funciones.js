$(function() {
     	 		$(".rslides").responsiveSlides({
     	 			auto:true,
     	 			speed:400,
     	 			speed:600,});
     	 	});
